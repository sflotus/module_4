package org.arthur.case_study.service.sub_service;

import org.arthur.case_study.model.sub_model.facility.FacilityType;

import java.util.List;

public interface IFacilityTypeService {
    List<FacilityType> getList();
}
