package org.arthur.case_study.service.sub_service;

import org.arthur.case_study.model.sub_model.employee.Position;

import java.util.List;

public interface IPositionService {
    List<Position> getList();

}
