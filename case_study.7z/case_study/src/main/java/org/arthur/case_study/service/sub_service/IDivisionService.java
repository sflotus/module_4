package org.arthur.case_study.service.sub_service;

import org.arthur.case_study.model.sub_model.employee.Division;

import java.util.List;

public interface IDivisionService {
    List<Division> getList();

}
