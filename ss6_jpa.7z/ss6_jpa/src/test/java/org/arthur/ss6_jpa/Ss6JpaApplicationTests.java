package org.arthur.ss6_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ss6JpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
