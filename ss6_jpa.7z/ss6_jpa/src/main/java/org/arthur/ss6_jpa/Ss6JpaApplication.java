package org.arthur.ss6_jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ss6JpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ss6JpaApplication.class, args);
    }

}
